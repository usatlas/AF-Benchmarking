# light-roast v0.0.1

---

<!-- sync the following div with docs/index.md -->
<div align="center">

<!-- --8<-- [start:badges] -->

<!-- prettier-ignore-start -->

| | |
| --- | --- |
| CI/CD | [![CI - Test][cicd-badge]][cicd-link] |
| Meta | [![GitLab - Issue][gitlab-issues-badge]][gitlab-issues-link] [![License - Apache][license-badge]][license-link] |

[cicd-badge]:            https://gitlab.cern.ch/radiative-decays/light-roast/badges/main/pipeline.svg
[cicd-link]:             https://gitlab.cern.ch/radiative-decays/light-roast/-/commits/main
[gitlab-issues-badge]:      https://img.shields.io/static/v1?label=Issues&message=File&color=blue&logo=gitlab
[gitlab-issues-link]:       https://gitlab.cern.ch/radiative-decays/light-roast/-/issues
[license-badge]:            https://img.shields.io/badge/License-Apache-blue.svg
[license-link]:             https://spdx.org/licenses/Apache-2.0.html

<!-- prettier-ignore-end -->

<!-- --8<-- [end:badges] -->

</div>

## Developer Notes

### Creating virtual environment

I recommend doing this all in a `venv`. Use your favorite, or from python like
so:

```bash
python -m venv venv
source venv/bin/activate
```

or if you want to run a script using the python from the virtual environment
instead of being inside of it, you can do

```bash
./venv/bin/python -m pip install ...
./venv/bin/python script.py ...
```

and so on.

### Installing

```bash
python -m pip install uv
python -m uv pip install -r requirements/light-roast.lock
python -m uv pip install -e .
```

### Developing/Contributing

Simply follow the install instructions above, and also install the `pre-commit`
hooks for this repository:

```bash
pre-commit install
```

See [pre-commit](https://pre-commit.com/) for more information on getting it and
using it.

### Upgrading Dependencies

This is managed using a lockfile at `requirements/light-roast.lock`. You can
upgrade by running

```bash
rm requirements/light-roast.lock
hatch env run --env lock -- python --version
```

### Running the example

```bash
python example.py
```

will run locally, using multiple processes, via `dask`, and produce a pdf with
photon $p_T$ for a few selections on the photon `isEM` bitmask documented
[in the egamma twiki](https://twiki.cern.ch/twiki/bin/view/AtlasProtected/EGammaIdentificationRun2#Photon_isEM_word).
