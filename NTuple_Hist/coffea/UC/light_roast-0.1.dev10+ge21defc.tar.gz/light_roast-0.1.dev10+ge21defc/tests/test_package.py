from __future__ import annotations

import importlib.metadata

import light_roast as m


def test_version():
    assert importlib.metadata.version("light_roast") == m.__version__
