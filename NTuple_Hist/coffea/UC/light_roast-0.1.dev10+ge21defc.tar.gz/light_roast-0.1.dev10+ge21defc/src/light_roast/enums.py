from __future__ import annotations

from enum import Enum

from light_roast.typing_compat import Annotated


# https://twiki.cern.ch/twiki/bin/viewauth/AtlasProtected/EGammaIdentificationRun2#Photon_isEM_word
class PhotonID(Enum):
    Rhad: Annotated[int, "ClusterHadronicLeakage_Photon"] = 10
    E277: Annotated[int, "ClusterMiddleEnergy_Photon"] = 11
    Reta: Annotated[int, "ClusterMiddleEratio37_Photon"] = 12
    Rphi: Annotated[int, "ClusterMiddleEratio33_Photon"] = 13
    Weta2: Annotated[int, "ClusterMiddleWidth_Photon"] = 14
    f1: Annotated[int, "ClusterStripsEratio_Photon"] = 15
    DeltaE: Annotated[int, "ClusterStripsDeltaE_Photon"] = 17
    Wstot: Annotated[int, "ClusterStripsWtot_Photon"] = 18
    fside: Annotated[int, "ClusterStripsFracm_Photon"] = 19
    Ws3: Annotated[int, "ClusterStripsWeta1c_Photon"] = 20
    ERatio: Annotated[int, "ClusterStripsDEmaxs1_Photon"] = 21

    def __getitem__(self, name):
        return getattr(self, name)
