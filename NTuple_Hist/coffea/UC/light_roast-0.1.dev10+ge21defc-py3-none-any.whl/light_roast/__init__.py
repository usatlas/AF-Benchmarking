"""
Copyright (c) 2024 Giordon Stark. All rights reserved.

light-roast: Collection of utilities and helper functions for analysing radiative decay ntuples
"""

from __future__ import annotations

from light_roast._version import version as __version__
from light_roast.enums import PhotonID

__all__ = ["__version__", "PhotonID"]
